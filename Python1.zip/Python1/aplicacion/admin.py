from django.contrib import admin
from .models import curso, Profesor, Entregable, Estudiante

# Register your models here.

admin.site.register(curso)
admin.site.register(Profesor)
admin.site.register(Entregable)
admin.site.register(Estudiante)
